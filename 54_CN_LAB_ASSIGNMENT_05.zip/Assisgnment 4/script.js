$(document).ready(function() {
    console.log('jQuery loaded:', typeof $ !== 'undefined');
    console.log('Bootstrap loaded:', typeof bootstrap !== 'undefined');
    
    // Dark Mode Toggle
    const darkModeToggle = $('#darkModeToggle');
    const html = $('html');
    const modeIcon = $('#modeIcon');
    const modeText = $('#modeText');
    
    // Check for saved theme preference
    const currentTheme = localStorage.getItem('theme') || 'light';
    html.attr('data-theme', currentTheme);
    updateToggleButton(currentTheme);
    
    // Toggle dark mode on click
    darkModeToggle.on('click', function() {
        const currentTheme = html.attr('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        html.attr('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateToggleButton(newTheme);
    });
    
    function updateToggleButton(theme) {
        if (theme === 'dark') {
            modeIcon.removeClass('fa-moon').addClass('fa-sun');
            modeText.text('Light Mode');
        } else {
            modeIcon.removeClass('fa-sun').addClass('fa-moon');
            modeText.text('Dark Mode');
        }
    }
    
    // Smooth scroll animation for tab content
    $('button[data-bs-toggle="pill"]').on('shown.bs.tab', function(e) {
        const targetPane = $($(e.target).data('bs-target'));
        if (targetPane.length) {
            $('html, body').animate({
                scrollTop: $('#projectTabContent').offset().top - 100
            }, 400);
        }
    });
    
    // Console log for debugging
    console.log('VIT Academic Projects Website Loaded Successfully!');
    console.log('Active tab:', $('.nav-link.active').text());
});
